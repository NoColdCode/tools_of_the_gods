
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.toolsofthegods.init;

import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.core.registries.Registries;

import net.mcreator.toolsofthegods.ToolsOfTheGodsMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class ToolsOfTheGodsModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ToolsOfTheGodsMod.MODID);

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {
			tabData.accept(ToolsOfTheGodsModItems.PRIMAL_WOODEN_TOOLS_SWORD.get());
		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {
			tabData.accept(ToolsOfTheGodsModItems.PRIMAL_WOODEN_TOOLS_PICKAXE.get());
			tabData.accept(ToolsOfTheGodsModItems.PRIMAL_WOODEN_TOOLS_AXE.get());
			tabData.accept(ToolsOfTheGodsModItems.PRIMAL_WOODEN_TOOLS_SHOVEL.get());
			tabData.accept(ToolsOfTheGodsModItems.PRIMAL_WOODEN_TOOLS_HOE.get());
			tabData.accept(ToolsOfTheGodsModItems.COMPLETED_PRIMAL_WOODEN_PICKAXE.get());
			tabData.accept(ToolsOfTheGodsModItems.CRUDE_STONEPICKAXE.get());
		}
	}
}
