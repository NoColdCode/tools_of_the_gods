package net.mcreator.toolsofthegods.procedures;

import net.minecraft.world.item.ItemStack;

public class PrimalWoodenToolsPickaxeItemIsCraftedsmeltedProcedure {
	public static void execute(ItemStack itemstack) {
		itemstack.getOrCreateTag().putDouble("xp", 0);
		itemstack.getOrCreateTag().putDouble("level", 0);
		itemstack.getOrCreateTag().putDouble("tier", 1);
		itemstack.getOrCreateTag().putDouble("nexttier", 32);
	}
}
