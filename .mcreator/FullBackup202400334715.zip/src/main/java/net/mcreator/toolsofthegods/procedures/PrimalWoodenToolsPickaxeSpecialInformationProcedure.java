package net.mcreator.toolsofthegods.procedures;

import net.minecraft.world.item.ItemStack;

public class PrimalWoodenToolsPickaxeSpecialInformationProcedure {
	public static String execute(ItemStack itemstack) {
		double filledBars = 0;
		String bar = "";
		filledBars = Math.round((itemstack.getOrCreateTag().getDouble("xp") / itemstack.getOrCreateTag().getDouble("nexttier")) * 10);
		if (filledBars > 10) {
			filledBars = 10;
		}
		bar = "";
		for (int index0 = 0; index0 < 10; index0++) {
			if (filledBars >= 1) {
				bar = bar + "\u25A0";
				filledBars = filledBars - 1;
			} else {
				bar = bar + "\u25A1";
			}
		}
		return "Xp : " + itemstack.getOrCreateTag().getDouble("xp") + " / " + itemstack.getOrCreateTag().getDouble("nexttier") + "\\n " + "Progression : " + bar + "\\n " + "Level : " + itemstack.getOrCreateTag().getDouble("level");
	}
}
