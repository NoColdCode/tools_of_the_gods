/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.toolsofthegods.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.toolsofthegods.item.PrimalWoodenToolsSwordItem;
import net.mcreator.toolsofthegods.item.PrimalWoodenToolsShovelItem;
import net.mcreator.toolsofthegods.item.PrimalWoodenToolsPickaxeItem;
import net.mcreator.toolsofthegods.item.PrimalWoodenToolsHoeItem;
import net.mcreator.toolsofthegods.item.PrimalWoodenToolsAxeItem;
import net.mcreator.toolsofthegods.item.CrudeStonepickaxeItem;
import net.mcreator.toolsofthegods.item.CompletedPrimalWoodenPickaxeItem;
import net.mcreator.toolsofthegods.ToolsOfTheGodsMod;

public class ToolsOfTheGodsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ToolsOfTheGodsMod.MODID);
	public static final RegistryObject<Item> PRIMAL_WOODEN_TOOLS_PICKAXE = REGISTRY.register("primal_wooden_tools_pickaxe", () -> new PrimalWoodenToolsPickaxeItem());
	public static final RegistryObject<Item> PRIMAL_WOODEN_TOOLS_AXE = REGISTRY.register("primal_wooden_tools_axe", () -> new PrimalWoodenToolsAxeItem());
	public static final RegistryObject<Item> PRIMAL_WOODEN_TOOLS_SWORD = REGISTRY.register("primal_wooden_tools_sword", () -> new PrimalWoodenToolsSwordItem());
	public static final RegistryObject<Item> PRIMAL_WOODEN_TOOLS_SHOVEL = REGISTRY.register("primal_wooden_tools_shovel", () -> new PrimalWoodenToolsShovelItem());
	public static final RegistryObject<Item> PRIMAL_WOODEN_TOOLS_HOE = REGISTRY.register("primal_wooden_tools_hoe", () -> new PrimalWoodenToolsHoeItem());
	public static final RegistryObject<Item> COMPLETED_PRIMAL_WOODEN_PICKAXE = REGISTRY.register("completed_primal_wooden_pickaxe", () -> new CompletedPrimalWoodenPickaxeItem());
	public static final RegistryObject<Item> CRUDE_STONEPICKAXE = REGISTRY.register("crude_stonepickaxe", () -> new CrudeStonepickaxeItem());
	public static final RegistryObject<Item> COMPRESSEDCOBBLE = block(ToolsOfTheGodsModBlocks.COMPRESSEDCOBBLE);

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}