package net.mcreator.toolsofthegods.procedures;

import net.minecraft.world.item.ItemStack;

public class CrudeStonepickaxeItemIsCraftedsmeltedProcedure {
	public static void execute(ItemStack itemstack) {
		itemstack.getOrCreateTag().putDouble("xp", 0);
		itemstack.getOrCreateTag().putDouble("level", 10);
		itemstack.getOrCreateTag().putDouble("tier", 2);
		itemstack.getOrCreateTag().putDouble("nexttier", 53);
	}
}