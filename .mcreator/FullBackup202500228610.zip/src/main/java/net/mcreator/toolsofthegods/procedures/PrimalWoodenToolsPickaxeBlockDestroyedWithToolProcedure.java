package net.mcreator.toolsofthegods.procedures;

import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.items.ItemHandlerHelper;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.Entity;
import net.minecraft.sounds.SoundSource;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.core.BlockPos;

import net.mcreator.toolsofthegods.init.ToolsOfTheGodsModItems;

public class PrimalWoodenToolsPickaxeBlockDestroyedWithToolProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity, ItemStack itemstack) {
		if (entity == null)
			return;
		if (itemstack.getOrCreateTag().getDouble("xp") <= itemstack.getOrCreateTag().getDouble("nexttier")) {
			itemstack.getOrCreateTag().putDouble("xp", (itemstack.getOrCreateTag().getDouble("xp") + 1));
		} else {
			if (itemstack.getOrCreateTag().getDouble("level") <= 8) {
				itemstack.getOrCreateTag().putDouble("level", Math.round(itemstack.getOrCreateTag().getDouble("level") + 1));
				itemstack.getOrCreateTag().putDouble("xp", Math.round(0));
				itemstack.getOrCreateTag().putDouble("nexttier", Math.round(32 + 9168 * Math.pow(itemstack.getOrCreateTag().getDouble("level") / 100, 2.63)));
				if (world instanceof Level _level) {
					if (!_level.isClientSide()) {
						_level.playSound(null, BlockPos.containing(x, y, z), ForgeRegistries.SOUND_EVENTS.getValue(ResourceLocation.parse("block.note_block.bell")), SoundSource.NEUTRAL, (float) 0.5, 1);
					} else {
						_level.playLocalSound(x, y, z, ForgeRegistries.SOUND_EVENTS.getValue(ResourceLocation.parse("block.note_block.bell")), SoundSource.NEUTRAL, (float) 0.5, 1, false);
					}
				}
			} else {
				itemstack.shrink(1);
				if (entity instanceof Player _player) {
					ItemStack _setstack = new ItemStack(ToolsOfTheGodsModItems.COMPLETED_PRIMAL_WOODEN_PICKAXE.get()).copy();
					_setstack.setCount(1);
					ItemHandlerHelper.giveItemToPlayer(_player, _setstack);
				}
			}
		}
	}
}