/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.toolsofthegods.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.toolsofthegods.item.*;
import net.mcreator.toolsofthegods.ToolsOfTheGodsMod;

public class ToolsOfTheGodsModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, ToolsOfTheGodsMod.MODID);
	public static final RegistryObject<Item> PRIMAL_WOODEN_TOOLS_PICKAXE;
	public static final RegistryObject<Item> PRIMAL_WOODEN_TOOLS_AXE;
	public static final RegistryObject<Item> PRIMAL_WOODEN_TOOLS_SWORD;
	public static final RegistryObject<Item> PRIMAL_WOODEN_TOOLS_SHOVEL;
	public static final RegistryObject<Item> PRIMAL_WOODEN_TOOLS_HOE;
	public static final RegistryObject<Item> COMPLETED_PRIMAL_WOODEN_PICKAXE;
	public static final RegistryObject<Item> CRUDE_STONEPICKAXE;
	public static final RegistryObject<Item> COMPRESSEDCOBBLE;
	static {
		PRIMAL_WOODEN_TOOLS_PICKAXE = REGISTRY.register("primal_wooden_tools_pickaxe", PrimalWoodenToolsPickaxeItem::new);
		PRIMAL_WOODEN_TOOLS_AXE = REGISTRY.register("primal_wooden_tools_axe", PrimalWoodenToolsAxeItem::new);
		PRIMAL_WOODEN_TOOLS_SWORD = REGISTRY.register("primal_wooden_tools_sword", PrimalWoodenToolsSwordItem::new);
		PRIMAL_WOODEN_TOOLS_SHOVEL = REGISTRY.register("primal_wooden_tools_shovel", PrimalWoodenToolsShovelItem::new);
		PRIMAL_WOODEN_TOOLS_HOE = REGISTRY.register("primal_wooden_tools_hoe", PrimalWoodenToolsHoeItem::new);
		COMPLETED_PRIMAL_WOODEN_PICKAXE = REGISTRY.register("completed_primal_wooden_pickaxe", CompletedPrimalWoodenPickaxeItem::new);
		CRUDE_STONEPICKAXE = REGISTRY.register("crude_stonepickaxe", CrudeStonepickaxeItem::new);
		COMPRESSEDCOBBLE = block(ToolsOfTheGodsModBlocks.COMPRESSEDCOBBLE);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return block(block, new Item.Properties());
	}

	private static RegistryObject<Item> block(RegistryObject<Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}
}